from npc.types import CNF, Assignment, Clause


def verify_solution(cnf: CNF, assignments: tuple[Assignment, Assignment]) -> bool:
    """
    Verify that assignments is a valid Double SAT solution to the cnf.
    """
    # Write your verification here.
    pass


def input_transformation(cnf: CNF) -> CNF:
    """
    Transform from a SAT input to a Double SAT input
    """
    # Write your transformation here.
    pass


def output_transformation(
    assignments: tuple[Assignment, Assignment] | None,
) -> Assignment | None:
    """
    Transform from a Double SAT output to a SAT output
    """
    # Write your transformation here.
    pass
