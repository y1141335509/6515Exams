import dc


def FriendlyCompetition(A: list[int]) -> int:
    pass
