def BusinessDivision(A: tuple[int]) -> tuple[bool, list[int], list[int]]:
    pass
