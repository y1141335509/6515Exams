def RaquelsBlocks(blue: list[int], red: list[int]) -> int:
    pass
